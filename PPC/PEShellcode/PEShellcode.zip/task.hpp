#pragma once

bool gh4t_shellcode();